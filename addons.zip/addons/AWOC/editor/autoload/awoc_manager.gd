@tool
class_name AWOCGlobalManager
extends Node

var awoc_resource_manager: AWOCLibraryManager


func _get_signal_bus() -> Node:
	return get_node_or_null("/root/SignalBus")
	
	
func _get_awoc_state() -> Node:
	return get_node_or_null("/root/AWOCState")
	
	
func _on_create_resource(data: Dictionary) -> void:
	if !data.has("type") or data.get("type").is_empty():
		return
	match data.get("type"):
		"awoc":
			var name = data.get("name", "")
			if name.is_empty():
				push_error("AWOC name required for AWOC creation")
				return
			var path = data.get("path", "")
			if path.is_empty():
				push_error("Path required for AWOC creation")
				return
			var new_awoc: AWOCResource = awoc_resource_manager.add_new_awoc(name, path)
			if new_awoc == null:
				push_error("New awoc could not be created")
				return
			var awoc_state = _get_awoc_state()
			if awoc_state:
				awoc_state.set_current_awoc(new_awoc)


func _on_rename_resource(resource_type: String, old_name: String, new_name: String) -> void:
	match resource_type:
		"awoc":
			awoc_resource_manager.rename_awoc(old_name,new_name)


func _on_delete_resource(resource_type: String, resource_name: String) -> void:
	match resource_type:
		"awoc":
			awoc_resource_manager.delete_awoc(resource_name)


func _ready() -> void:
	awoc_resource_manager = AWOCLibraryManager.new()
	awoc_resource_manager = awoc_resource_manager.load_welcome_resource_manager()
	var bus = _get_signal_bus()
	if bus:
		bus.create_new_resource_requested.connect(_on_create_resource)
		bus.delete_resource_requested.connect(_on_delete_resource)
		bus.rename_resource_requested.connect(_on_rename_resource)


func _exit_tree() -> void:
	var bus = _get_signal_bus()
	if bus:
		if bus.create_new_resource_requested.is_connected(_on_create_resource):
			bus.create_new_resource_requested.disconnect(_on_create_resource)
		if bus.delete_resource_requested.is_connected(_on_delete_resource):
			bus.delete_resource_requested.disconnect(_on_delete_resource)
		if bus.rename_resource_requested.is_connected(_on_rename_resource):
			bus.rename_resource_requested.disconnect(_on_rename_resource)
