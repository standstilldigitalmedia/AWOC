@tool
class_name AWOCManagementList
extends AWOCManagementListBase

var awoc_manager_library: AWOCLibraryManager


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	awoc_manager_library = AWOCLibraryManager.new()
	awoc_manager_library = awoc_manager_library.load_welcome_resource_manager()
	if awoc_manager_library == null:
		push_error("Failed to load AWOC manager library")
		return
	var awoc_row_manager_path: String = AWOCEditorGlobal.PLUGIN_PATH.path_join("editor/UI_elements/management_rows/awoc_management_row/awoc_row_manager.tscn")
	var name_array = awoc_manager_library.get_sorted_name_array()
	clear_children()
	for awoc_name in name_array:
		var row_manager_scene: PackedScene = load(awoc_row_manager_path)
		var row_manager = row_manager_scene.instantiate()
		row_manager.set_control(awoc_name, "awoc")
		add_child(row_manager)
