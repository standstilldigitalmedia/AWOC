@tool
class_name AWOCManagementListBase
extends VBoxContainer


func clear_children() -> void:
	for child in get_children():
		child.queue_free()
