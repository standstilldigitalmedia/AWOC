@tool
class_name AWOCRowManager
extends AWOCBaseManagementRow


func _on_edit_button_pressed() -> void:
	#will be implemented soon
	pass # Replace with function body.
