@tool
class_name AWOCLibraryManager
extends AWOCEditorDiskResourceManager

@export var awoc_uid_dictionary: Dictionary = {}


func add_new_awoc(awoc_name: String, asset_path: String) -> AWOCResource:
	var new_awoc: AWOCResource = AWOCResource.new()
	if create_resource_on_disk(new_awoc, awoc_name, asset_path):
		save_parent_resource()
		return new_awoc
	return null


func delete_awoc(awoc_name: String) -> void:
	if delete_resource_from_disk(awoc_name):
		save_parent_resource()


func rename_awoc(old_name: String, new_name: String) -> void:
	if !awoc_uid_dictionary.has(old_name):
		push_error("AWOC not found: " + old_name)
		return
	var resource_ref = awoc_uid_dictionary.get(old_name)
	if resource_ref == null:
		push_error("Invalid resource reference for: " + old_name)
		return
	if rename_resource_on_disk(old_name, new_name, resource_ref.get_uid()):
		save_parent_resource()


func load_welcome_resource_manager() -> AWOCLibraryManager:
	var welcome_resource: AWOCLibraryManager
	var welcome_path: String = AWOCEditorGlobal.PLUGIN_PATH.path_join("begin_here")
	if FileAccess.file_exists(welcome_path):
		welcome_resource = load(welcome_path) as AWOCLibraryManager
		if welcome_resource == null:
			printerr("Unable to load AWOCLibraryManager")
			return null
	else:
		welcome_resource = AWOCLibraryManager.new()
		create_resource_on_disk(welcome_resource, "welcome", AWOCEditorGlobal.PLUGIN_PATH.path_join("begin_here"))
	var uid = ResourceLoader.get_resource_uid(welcome_path)
	welcome_resource.init_resource_manager(welcome_resource, uid, welcome_resource.awoc_uid_dictionary)
	return welcome_resource
